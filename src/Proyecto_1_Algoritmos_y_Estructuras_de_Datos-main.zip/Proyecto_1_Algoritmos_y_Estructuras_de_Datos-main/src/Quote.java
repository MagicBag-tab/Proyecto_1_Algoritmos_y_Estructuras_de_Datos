public class Quote{

    //El método quote retorna lo mismo que recibe
    public Object quote(Object expr){
        return expr;
    }
}
